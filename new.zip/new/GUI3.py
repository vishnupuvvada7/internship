
import os
import subprocess
import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QPushButton, QTextEdit, QComboBox, QMessageBox
)
from PyQt5.QtGui import QIcon, QPixmap, QFont
from PyQt5.QtCore import Qt

class CASAuditTool(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("CAS AUDIT TOOL")
        self.setGeometry(100, 100, 800, 600)

        self.initUI()

    def initUI(self):
        # Top frame
        top_frame = QWidget(self)
        top_frame.setStyleSheet("""
            background-color: #f4f4f4;
            color: #333;
            padding: 10px;
        """)

        layout_top = QHBoxLayout(top_frame)
        layout_top.setContentsMargins(10, 10, 10, 10)

        # CAS image
        cas_image = QLabel(self)
        cas_image.setPixmap(QPixmap("CAS.jpeg").scaled(80, 80))
        layout_top.addWidget(cas_image)

        # Heading label
        heading_label = QLabel("CAS AUDIT TOOL", self)
        heading_label.setStyleSheet("color: #333;")
        heading_label.setFont(QFont("Arial", 18, QFont.Bold))
        layout_top.addWidget(heading_label, 1, Qt.AlignLeft | Qt.AlignVCenter)

        # Set top frame layout
        self.setMenuWidget(top_frame)

        # Button frame
        button_frame = QWidget(self)
        layout_button = QHBoxLayout(button_frame)

        layout_button.setContentsMargins(20, 20, 20, 20)

        # Create buttons
        about_button = QPushButton("About", self)
        about_button.clicked.connect(self.open_about_window)
        about_button.setStyleSheet("""
            background-color: #0056b3;
            color: #fff;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        """)
        layout_button.addWidget(about_button)

        manual_button = QPushButton("Manual", self)
        manual_button.clicked.connect(self.open_manual_window)
        manual_button.setStyleSheet("""
            background-color: #0056b3;
            color: #fff;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        """)
        layout_button.addWidget(manual_button)

        disable_button = QPushButton("Disable Services", self)
        disable_button.clicked.connect(self.disable_services)
        disable_button.setStyleSheet("""
            background-color: #0056b3;
            color: #fff;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        """)
        layout_button.addWidget(disable_button)

        audit_button = QPushButton("Run Audit", self)
        audit_button.clicked.connect(self.run_audit)
        audit_button.setStyleSheet("""
            background-color: #0056b3;
            color: #fff;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        """)
        layout_button.addWidget(audit_button)

        result_button = QPushButton("Open Result File", self)
        result_button.clicked.connect(self.open_result_file)
        result_button.setStyleSheet("""
            background-color: #0056b3;
            color: #fff;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        """)
        layout_button.addWidget(result_button)

        logs_button = QPushButton("Generate Logs", self)
        logs_button.clicked.connect(self.logs_generation)
        logs_button.setStyleSheet("""
            background-color: #0056b3;
            color: #fff;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        """)
        layout_button.addWidget(logs_button)

        # Options combo box and Clear button
        options_frame = QWidget(self)
        layout_options = QVBoxLayout(options_frame)
        layout_options.setContentsMargins(20, 20, 20, 20)

        options = ["Recycle Bin", "%Temp Files", "temp", "prefetch"]
        self.combo = QComboBox(self)
        self.combo.addItems(options)
        layout_options.addWidget(self.combo)

        clear_button = QPushButton("Clear", self)
        clear_button.clicked.connect(self.select_option)
        clear_button.setStyleSheet("""
            background-color: #0056b3;
            color: #fff;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        """)
        layout_options.addWidget(clear_button)

        # Result text box
        result_text_frame = QWidget(self)
        layout_result_text = QVBoxLayout(result_text_frame)
        layout_result_text.setContentsMargins(20, 20, 20, 20)

        self.result_text = QTextEdit(self)
        self.result_text.setReadOnly(True)
        self.result_text.setStyleSheet("""
            background-color: #333333;
            color: #ffffff;
            padding: 10px;
            font-size: 12px;
        """)
        layout_result_text.addWidget(self.result_text)

        # Main layout
        main_layout = QVBoxLayout()
        main_layout.addWidget(button_frame)
        main_layout.addWidget(options_frame)
        main_layout.addWidget(result_text_frame)

        central_widget = QWidget(self)
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def get_executable_directory(self):
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        else:
            return os.path.dirname(os.path.realpath(__file__))

    def run_audit(self):
        try:
            executable_dir = self.get_executable_directory()
            bat_file_path = os.path.join(executable_dir, "retrieval.bat")
            result = subprocess.run([bat_file_path], capture_output=True, text=True, shell=True)
            
            # Check the result and print or display in QTextEdit
            if result.returncode == 0:
                output = result.stdout
                self.result_text.setPlainText(output)
                self.result_text.setPlainText("Successfully executed")
            else:
                error_output = result.stderr if result.stderr else "Unknown error"
                self.result_text.setPlainText(f"Error executing services.bat: {error_output}")
            
        
        except Exception as e:
            self.result_text.setPlainText(f"Error: {e}")

    def open_result_file(self):
        try:
            executable_dir = self.get_executable_directory()
            file_path = os.path.join(executable_dir, "Audit_report.pdf")
            if os.path.exists(file_path):
                os.startfile(file_path)
        except Exception as e:
            self.result_text.setPlainText(f"Error: {e}")

    def disable_services(self):
        try:
            executable_dir = self.get_executable_directory()
            bat_file_path = os.path.join(executable_dir, "services.bat")
            
            # Execute the batch file and capture output
            result = subprocess.run([bat_file_path], capture_output=True, text=True, shell=True)
            
            # Check the result and print or display in QTextEdit
            if result.returncode == 0:
                output = result.stdout
                self.result_text.setPlainText(output)
                self.result_text.setPlainText("Successfully executed")
            else:
                error_output = result.stderr if result.stderr else "Unknown error"
                self.result_text.setPlainText(f"Error executing services.bat: {error_output}")
        
        except Exception as e:
            self.result_text.setPlainText(f"Error: {e}")

    def logs_generation(self):
        try:
            executable_dir = self.get_executable_directory()
            bat_file_path = os.path.join(executable_dir, "logs_generation.bat")
            result = subprocess.run([bat_file_path], capture_output=True, text=True, shell=True)
            
            # Check the result and print or display in QTextEdit
            if result.returncode == 0:
                output = result.stdout
                self.result_text.setPlainText(output)
                self.result_text.setPlainText("Successfully executed")
            else:
                error_output = result.stderr if result.stderr else "Unknown error"
                self.result_text.setPlainText(f"Error executing services.bat: {error_output}")
        
        except Exception as e:
            self.result_text.setPlainText(f"Error: {e}")

    def open_about_window(self):
        about_text = """
                <h2>About CAS Audit Tool</h2>
                <table border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse;">
                    <tr><th>Function</th><th>Description</th></tr>
                    <tr><td>Run Audit</td><td>This button generates the general data related to the PC</td></tr>
                    <tr><td>Result File</td><td>This button retrieves the PDF generated by 'run audit' and displays it to the user</td></tr>
                    <tr><td>Logs</td><td>This button generates the Windows Logs, USB logs, and DNS logs</td></tr>
                    <tr><td>Automate services</td><td>This button disables the RDP services, telnet, and enforces 6 out of 9 secpol policies</td></tr>
                    <tr><td>Manual</td><td>The data displayed in this button are the manual tasks to be performed by the IT auditor</td></tr>
                    <tr><td>Drop-Down</td><td>The dropdown selects the type of cache files to be deleted, and the CLEAR button deletes the data accordingly</td></tr>
                    <tr><td>NOTE1</td><td>The logs take time to generate, please wait for at least 5 minutes. They will be generated in a folder on the desktop</td></tr>
                    <tr><td>NOTE2</td><td>THE TOOL MUST BE RUN IN ADMIN USER TO PERFORM DESIRED TASKS</td></tr>
                    <tr><td>NOTE3</td><td>Child exited with code 0: Something unknown happened executing the batch. [EXECUTED SUCCESSFULLY]</td></tr>
                    <tr><td>NOTE4</td><td>Child exited with code 1: The file already exists [EXECUTION FAILED]</td></tr>
                </table>
                """

        QMessageBox.about(self, "About CAS Audit Tool", about_text)

    def open_manual_window(self):
        manual_text = """
        <h2>Manual Tasks</h2>
        <table border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse;">
            <tr><th>Task</th><th>Steps</th></tr>
            <tr><td>Last Update Of Antivirus</td><td>Check In Antivirus</td></tr>
            <tr><td>Disable AutoPlay</td><td>In Windows Settings</td></tr>
            <tr><td>Disable Password Auto-Save</td><td>Password Settings In Browser</td></tr>
            <tr><td>Unwanted Softwares Delete</td><td>Use Control Panel</td></tr>
            <tr><td>secpol.msc->Acc pol->Pass pol</td><td>Password must meet complexity [Enable]</td></tr>
            <tr><td>secpol.msc->Local pol->Sec options</td><td>Machine inactivity limit [60secs]</td></tr>
            <tr><td>secpol.msc->Local pol->Acc Lockout Pol</td><td>Reset account lockout [10mins]</td></tr>
            <tr><td>If Bios-Password not Set</td><td>
                <ul>
                    <li>Set Bios Password</li>
                    <li>Restart the PC</li>
                    <li>Press f2 continuously</li>
                    <li>Security</li>
                    <li>Set password or set user password</li>
                    <li>Enter new password: Pass@123</li>
                    <li>Confirm new password: Pass@123</li>
                    <li>Press enter and pop up setup notice will appear which means that you have to reset BIOS PASSWORD</li>
                    <li>Press f10 to save it and select yes to exit the PC will log on automatically.</li>
                </ul>
            </td></tr>
            <tr><td>Keys to Boot menu</td><td>
                <ul>
                    <li>Acer: press f2 or del</li>
                    <li>Asus: press f2 or del</li>
                    <li>Dell: press f2 or f12</li>
                    <li>Hp: press esc or f10</li>
                    <li>Lenovo desktop: f1</li>
                    <li>Lenovo laptop: press f2</li>
                    <li>Lenovo thinkpad: press enter+f1</li>
                </ul>
            </td></tr>
        </table>
        """

        QMessageBox.about(self, "Manual Tasks", manual_text)
    def select_option(self):
        selected_option = self.combo.currentText()
        if selected_option == "Recycle Bin":
            try:
                result=subprocess.run(["python", "clearRecycle.py"], check=True, text=True, capture_output=True)
                self.result_text.setPlainText(result.stdout)
            except Exception as e:
                self.result_text.setPlainText(f"Error: {e}")

        elif selected_option == "%Temp Files":
            try:
                result=subprocess.run(["python", "clear_Temp.py"], check=True, text=True, capture_output=True) 
                self.result_text.setPlainText(result.stdout)
            except Exception as e:
                self.result_text.setPlainText(f"Error: {e}")

        elif selected_option == "temp":
            try:
                executable_dir = self.get_executable_directory()
                bat_file_path = os.path.join(executable_dir, "temp.bat")
                result = subprocess.run([bat_file_path], capture_output=True, text=True)
                
                # Check the result and print or display in QTextEdit
                if result.returncode == 0:
                    output = result.stdout
                    self.result_text.setPlainText(output)
                    self.result_text.setPlainText("Successfully executed")
                else:
                    error_output = result.stderr if result.stderr else "Unknown error"
                    self.result_text.setPlainText(f"Error executing services.bat: {error_output}")
        
            except Exception as e:
                self.result_text.setPlainText(f"Error: {e}")

        elif selected_option == "prefetch":
            try:
                result = subprocess.run(["python", "prefetch.py"], check=True, text=True, capture_output=True)
                self.result_text.setPlainText(result.stdout)
            except Exception as e:
                self.result_text.setPlainText(f"Error: {e}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CASAuditTool()
    window.show()
    sys.exit(app.exec_())
